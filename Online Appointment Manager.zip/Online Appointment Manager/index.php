<!DOCTYPE html>
<html>
<body>
<form action="logging.php" method="post">
Username
<input type="text" id="username" name="username"> <br>
Password
<input type="text" id="password" name="password"> <br>
<input type="submit" value="login">
</form>
</body>
</html>
<?php
require_once 'connection.php';
#select all open dates
$query = "SELECT * FROM dates where open ='0'";
$result = mysqli_query($con, $query);
$r = mysqli_num_rows($result);

echo "<br><h2>Available appointments:</h2>";

#adds all dates to the table with an appoint button
if ($r === 0) {
	echo "No available dates right now.";
	}
	else {
	echo "<table border='1'>";
	echo "<tr>";
	echo "<td>Date</td>";
	echo "</tr>";

	#adds all dates to the table with an appoint button
	for ($k=0; $k < $r; $k++) {
		$row = mysqli_fetch_assoc($result);
		$time = $row['time'];
		echo "<tr><td>$time</td></tr>";
	}
	echo "</table>";
}
?>