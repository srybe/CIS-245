<?php 
require_once('connection.php');
session_start();
if(isset($_SESSION['isloggedin']) && $_SESSION['isloggedin'] == 1){
    
    echo "<b> Welcome </b>". $_SESSION['email']. "<br>";
    echo "<br> <a href = 'logout.php'>logout </a>";
    echo "<hr>";

    echo "<b> <h1> Add your own status </h1> </b><br>";
    echo "<form method = 'post'>";
    echo "<input type='text' name='status' placeholder ='Whats on your mind?'>";
    echo " Private? <input type='checkbox' name = 'private'>";
    echo "<input type='submit' value = 'publish'><br>";
    echo "</form>";
    $status_id = isset($_POST['status_id']);
    $status_text = $_POST['status_text'];

    $user_email = $_SESSION['email'];
    $status_property = isset($_POST['private']);
    $query1 = "INSERT INTO status (status_id, user_email, status_text, status_property) VALUES ('$user_email', '$status_text','$status_property')";
    
    echo "<br><hr>";

    echo "<b> <h1> Timeline </h1> </b><br>";
    $email = $_SESSION['email'];
    $query = "SELECT * FROM status WHERE user_email = '$email'";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
            echo $row['status_text'] . "<br>";
        }
    }
    
}
else {
    header('location:index.php');
}
?>
