<!DOCTYPE html>
<html>
<body>


<?php
require_once 'connection.php';
$username = $_POST["username"];
$password = $_POST["password"];

$query = "SELECT * FROM users WHERE username = '$username' and password = '$password'";
$result = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($result);

if (mysqli_num_rows($result)==0) {
    header('location:index.php');
} else {
    session_start();
    $_SESSION['isloggedin']=1;
    $_SESSION['id']=$row["u_id"];
    $_SESSION['username']=$row["username"];
    header('location:main.php');
}

?>

</body>
</html>