<?php
session_start();
$id = $_SESSION['id'];
require_once 'connection.php';

/*
echo "POST - ";
print_r($_POST);          //$_POST = d_id
echo "<br> SESSION - ";     //$id = u_id
print_r($_SESSION);
*/

if(isset($_POST['d_id']) && isset($_SESSION['id'])){
    $d_id = $_POST['d_id'];
    
    $query = "insert into appointments (u_id, d_id) value ('$id', '$d_id')";
    $query2 = "Update dates set open = 1 where d_id = '$d_id'";
    mysqli_query($con, $query);
    mysqli_query($con, $query2);
    header('location:main.php');
}


?>
