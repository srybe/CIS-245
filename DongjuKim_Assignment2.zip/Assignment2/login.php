<?php 
require_once('connection.php');

$u = $_POST['user'];
$p = $_POST['pass'];
$query = "Select * from users where user_email = '$u' and password = '$p'";
$result = mysqli_query($conn, $query);

if(mysqli_query($conn, $query) === true){
    $query = "INSERT INTO users (user_email, password) VALUES ('$u', '$p')";
}

if(mysqli_num_rows($result)==0){
    header('location:index.php');
}

else{
    session_start();
    $_SESSION['isloggedin'] = 1;
    $_SESSION['email'] = $u;
    header('location:welcome.php');
}

?>