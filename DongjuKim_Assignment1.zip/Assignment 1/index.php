<html lang="en">
    

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>index</title>
</head>
<body>

    <h1>Hot sandwiches</h1>
    <form method = "post">

    <table>
        <tr>
            <td>Name</td>
            <td><input type="text" name="name"></td>

        </tr>
        <tr>
            <td>Phone Number</td>
            <td><input type="text" name="phone"></td>
        </tr>
    </table>

<hr>

    <table border="2">
        <tr>
            <th> Item ID </th>         <!-- form header a-->
            <th> Item description</th>
            <th> Price</th>
            <th> Quantity</th>
        </tr>
        <tr>
            <td> 1</td>                <!-- 1st item a-->
            <td> Hot Beef</td>
            <td> $8</td>
            <td>
            <select name="beefAmount">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            </select>
            </td>
        </tr>
       <tr>
            <td> 2</td>                <!-- 2nd item a-->
            <td> Hot steak</td>
            <td> $8</td>
            <td> 
            <select name="steakAmount">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            </select>
            </td>
        </tr>
        <tr>
            <td> 3</td>                <!-- 3rd item a-->
            <td> Hot Hamburger</td>
            <td> $10</td>
            <td>
            <select name="burgerAmount">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            </select>
            </td>
        </tr>
    </table>
    <br>
    Choose payment method
    <br>

    Credit Card  <input type = "radio" name = "pay" value = "credit card">       <!-- Same name  a-->

    Cash <input type = "radio" name = "pay" value="cash">            <!-- Only allow 1 item to be selected a-->
<br>
<input type="submit" name = "submit" value="Order Now!">

<input type="reset" name = "reset" value="Clear form!">
</form>

<?php
    $name = $_POST["name"];
    $beefAmount = $_POST["beefAmount"];
    $steakAmount = $_POST["steakAmount"];
    $burgerAmount = $_POST["burgerAmount"];
    $total = ($beefAmount * 8) + ($steakAmount * 8) + ($burgerAmount * 10); // math on prices
    
    if(isset($_POST['submit'])){
        if(isset($_POST['pay'])){
            echo "Hi " . $name . " the total amount of your order is $" . $total . ", you chose to pay by ". $_POST['pay'];

        }
        else if(isset($_POST['reset'])){    // reseting the page but it does not reset the previous submit
        reset_($_POST);
    }
        else {
            echo "Please finish inputting";     // if the user missed an input
        }
    }

?>

</body>
</html> 


