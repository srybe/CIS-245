<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="login.php" method="post">
        <input type="text" name="user" placeholder="user email">
        <input type="password" name="pass" placeholder ="password">
        <input type="submit">
    </form>
    
</body>
<?php 

require_once('connection.php');

$query = "SELECT * FROM status WHERE status_property = 1"; 
$result = mysqli_query($conn, $query);

echo "<b><h1>Timeline </h1></b>";

if(mysqli_num_rows($result) > 0){
    while($row = $result ->fetch_assoc()){
        echo $row["status_text"]. "<br>";
        echo "Posted by: ". $row["user_email"]. "<br>";
    }

}
else {
    echo "<b>No public status to show. Please log in</b>";
}

?>
</html>