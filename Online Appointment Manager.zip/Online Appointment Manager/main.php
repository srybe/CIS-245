<!DOCTYPE html>
<html>
<body>
<?php

require_once 'connection.php';
session_start();
$name = $_SESSION['username'];
$id = $_SESSION['id'];
if(isset($_SESSION['isloggedin']) && $_SESSION['isloggedin']==1) {
	echo "<h1> Welcome ", $name, "</h1>";
	echo "<a href='logout.php'>logout</a>";
}
else {
	header('location:index.php');
}
#select all open dates
$query = "SELECT * FROM dates where open ='0'";
$result = mysqli_query($con, $query);
$r = mysqli_num_rows($result);

#builds the table
if ($r === 0) {
	echo "<br><h2>Available appointments:</h2>";
	echo "No available dates right now.";
	}
	else {
	echo "<table border='1'>";
	echo "<tr>";
	echo "<td>Date</td>";
	echo "<td>Appoint</td>";
	echo "</tr>";

	#adds all dates to the table with an appoint button
	for ($k=0; $k < $r; $k++) {
		$row = mysqli_fetch_assoc($result);
		$time = $row['time'];
		echo "<tr><td>$time</td>";
		echo "<td><form action='appoint.php' method='post'>"; 
		echo "<input type='hidden' value='$row[d_id]' name='d_id' id='d_id'> </input>";
		echo "<input type='submit' value='Add appointment'>";
		echo "</form></td></tr>";
	}
	echo "</table>";
}

#select date id's user is appointed to
$query2 = "SELECT * FROM appointments where u_id ='$id'";
$result2 = mysqli_query($con, $query2);
$r2 = mysqli_num_rows($result2);

#builds the table if appointed
echo "<br><h2>Dates you are appointed to:</h2>";
if ($r2 === 0) {
	echo "You are not appointed to any dates right now.";
}
else {
	echo "<table border='1'>";
	echo "<tr>";
	echo "<td>Date</td>";
	echo "<td>Remove</td>";
	echo "</tr>";

	#selects appointed user id's from dates database
	for ($k=0; $k < $r2; $k++) {
		$row2 = mysqli_fetch_assoc($result2);
		$query3 = "SELECT * FROM dates where d_id ='$row2[d_id]'";
		$result3 = mysqli_query($con, $query3);
		$row3 = mysqli_fetch_assoc($result3);
		$time2 = $row3['time'];
		echo "<tr><td>$time2</td>";
		echo "<td><form action='remove.php' method='post'>"; 
		echo "<input type='hidden' value='$row2[d_id]' name='d_id' id='d_id'> </input>";
		echo "<input type='submit' value='Remove'>";
		echo "</form></td></tr>";
	}
	echo "</table>";
}


?>
</body>
</html>